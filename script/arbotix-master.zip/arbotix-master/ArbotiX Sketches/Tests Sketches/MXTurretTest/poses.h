#ifndef POSES
#define POSES

#include <avr/pgmspace.h>

PROGMEM prog_uint16_t Center[] = {2, 2048, 2048};


#endif
