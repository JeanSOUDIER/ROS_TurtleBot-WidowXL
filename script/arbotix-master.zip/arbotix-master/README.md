This is a fork of the Vanadium Labs ArbotiX libraries
https://github.com/vanadiumlabs/arbotix

This fork is avialable as a convience for InterbotiX kits users. Itincludes several sketches to help users get started and testing their robots.

This is NOT a development fork. For the newest releases of the ArbotiX Libraries, see the link above.

See docs at http://vanadiumlabs.github.io/arbotix/
